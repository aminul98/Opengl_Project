#include <iostream>
#include<GL/gl.h>
#include <GL/glut.h>
#include <math.h>
using namespace std;

float movea = 0.0f;
float moveb = 0.0f;
float angle1 = 0.0f;
float speed = 0.02f;

void drawScene() {
    glClearColor(1.0f,1.0f,1.0f,1.0f);
    glClear(GL_COLOR_BUFFER_BIT); /// Clear the color buffer with current clearing color
    glColor3d(1,0,0);
    glLoadIdentity(); /// Set the matrix to an "identity" state.
    gluOrtho2D(14,38,-19,14);///coordinate xy range
    glMatrixMode(GL_MODELVIEW);///Applies subsequent matrix operations to the modelview matrix stack.


    ///sky///
    glBegin(GL_POLYGON);/// Draw a Red 1x1 Square centered at origin
    glColor3ub(135,206,250);
    glVertex2f(38.0f,3.0f);
    glVertex2f(38.0f,14.0f);
    glVertex2f(14.0f,14.0f);
    glVertex2f(14.0f,3.0f);

    glEnd();

     ///sun///
    glPushMatrix(); /// Save the identity matrix.
    glColor3d(255,255,0);
    glTranslatef(30.0, 7.0, 0);
    glutSolidSphere(1.0, 250, 250); ///render a solid or wireframe sphere respectively.
    glPopMatrix(); /// Restore the identity matrix.

    ///cloud 1///
    glPushMatrix();
    glTranslatef(moveb,0.0f,0.0f);
    glPushMatrix();
    glColor3d(255,255,255);
    glTranslatef(1.0, 6.0, 0);
    glutSolidSphere(0.7, 250, 250); ///render a solid or wireframe sphere respectively.
    glPopMatrix();

    glPushMatrix(); /// cloud circle
    glColor3d(255,255,255);
    glTranslatef(1.0, 7.0, 0);
    glutSolidSphere(0.7, 250, 250);///render a solid or wireframe sphere respectively.
    glPopMatrix();

    glPushMatrix();
    glColor3d(255,255,255);
    glTranslatef(2.0, 7.0, 0);
    glutSolidSphere(0.7, 250, 250);
    glPopMatrix();

    glPushMatrix();
    glColor3d(255,255,255);
    glTranslatef(2.0, 6.0, 0);
    glutSolidSphere(0.7, 250, 250);
    glPopMatrix();

    glPushMatrix();
    glColor3d(255,255,255);
    glTranslatef(0.0, 6.5, 0);
    glutSolidSphere(0.7, 250, 250);
    glPopMatrix();

    glPushMatrix();
    glColor3d(255,255,255);
    glTranslatef(3.0, 6.5, 0);
    glutSolidSphere(0.7, 250, 250);
    glPopMatrix();

    glPopMatrix();

///cloud 2///

    glPushMatrix();

    glTranslatef(moveb,0.0f,0.0f);
    glPushMatrix();
    glColor3d(255,255,255);
    glTranslatef(15.0, 9.0, 0);
    glutSolidSphere(0.8, 250, 250);
    glPopMatrix();

     glPushMatrix();
    glColor3d(255,255,255);
    glTranslatef(15.0, 8.0, 0);
    glutSolidSphere(0.8, 250, 250);
    glPopMatrix();

    glPushMatrix();
    glColor3d(255,255,255);
    glTranslatef(16.0, 8.0, 0);
    glutSolidSphere(0.8, 250, 250);
    glPopMatrix();

    glPushMatrix();
    glColor3d(255,255,255);
    glTranslatef(16.0, 9.0, 0);
    glutSolidSphere(0.8, 250, 250);
    glPopMatrix();

    glPushMatrix();
    glColor3d(255,255,255);
    glTranslatef(14.0, 8.5, 0);
    glutSolidSphere(0.8, 250, 250);
    glPopMatrix();

    glPushMatrix();
    glColor3d(255,255,255);
    glTranslatef(17.0, 8.5, 0);
    glutSolidSphere(0.8, 250, 250);
    glPopMatrix();

    glPopMatrix();



  ///sea portion///
    glBegin(GL_POLYGON);/// Draw a Red 1*1 Square centered at origin
    glColor3ub(65,105,225);
    glVertex2f(38.0f,-19.0f);
    glVertex2f(38.0f,3.0f);
    glVertex2f(14.0f,3.0f);
    glVertex2f(14.0f,-19.0f);

    glEnd();


///soil portion///

///polygon1

    glBegin(GL_POLYGON);
    glColor3ub(0,128,0);
    glVertex2f(14.0f,3.0f);
    glVertex2f(14.0f,-9.0f);
    glVertex2f(38.0f,1.0f);
    glVertex2f(38.0f,3.0f);

    glEnd();

///polygon2
    glBegin(GL_POLYGON);

    glColor3ub(0,128,0);
    glVertex2f(14.0f,-9.0f);
    glVertex2f(38.0f,-9.0f);
    glVertex2f(38.0f,1.0f);

    glEnd();

///    HOUSE       //

///polygon1//
    glBegin(GL_POLYGON); ///uper roft front side
    glColor3ub(25,25,112);
    glVertex2f(25.3,1.2);
    glVertex2f(21.3,1.2);
    glVertex2f(23,-1);
    glVertex2f(27,-1);

    glEnd();

///polygon2//
    glBegin(GL_POLYGON);///uper roft back side
    glColor3ub(25,25,112);;
    glVertex2f(21.5,1);
    glVertex2f(21.3,1.2);
    glVertex2f(19.5,-1);
    glVertex2f(20,-1);

    glEnd();

///polygon3///
    glBegin(GL_POLYGON); ///left side wall
    glColor3ub(184,134,11);
    glVertex2f(21.5,1);
    glVertex2f(20,-1);
    glVertex2f(20,-2.5);
    glVertex2f(23,-3);
    glVertex2f(23,-1);

    glEnd();

///polygon4///
   glBegin(GL_POLYGON); /// left side wall window

    glColor3ub(160,82,45);
    glVertex2f(22,-2);
    glVertex2f(22,-1);
   glVertex2f(21,-1);
    glVertex2f(21,-2);

    glEnd();

///polygon5///
    glBegin(GL_POLYGON);/// left side bottom wall
     glColor3ub(47,79,79);
    glVertex2f(23,-3);
    glVertex2f(20,-2.5);
    glVertex2f(19.7,-2.9);
    glVertex2f(23,-3.5);

    glEnd();

///polygon6///
   glBegin(GL_POLYGON); ///front side wall

   glColor3ub(205,133,63);
    glVertex2f(26.5,-3);
    glVertex2f(26.5,-1);
    glVertex2f(23,-1);
    glVertex2f(23,-3);

    glEnd();

///polygon7///
    glBegin(GL_POLYGON);/// front side bottom wall
    glColor3ub(47,79,79);
    glVertex2f(23,-3);
    glVertex2f(23,-3.5);
    glVertex2f(27,-3.5);
    glVertex2f(26.5,-3);

    glEnd();

///door///
///polygon a///
    glBegin(GL_POLYGON); /// door shap
    glColor3ub(0,0,0);
    glVertex2f(25.5,-3);
    glVertex2f(25.5,-1.2);
    glVertex2f(24,-1.2);
    glVertex2f(24,-3);

    glEnd();

///polygon b///
    glBegin(GL_POLYGON);/// door left side shap
    glColor3ub(160,82,45);
    glVertex2f(24.7,-3);
    glVertex2f(24.7,-1.4);
    glVertex2f(24,-1.2);
    glVertex2f(24,-3);

    glEnd();

///polygon c///
    glBegin(GL_POLYGON);///door right side shap

    glColor3ub(160,82,45);
    glVertex2f(25.5,-3);
    glVertex2f(25.5,-1.2);
    glVertex2f(24.8,-1.4);
    glVertex2f(24.8,-3);

    glEnd();

///hill view///

///hill 1///
///polygon1///
    glBegin(GL_POLYGON);
    glColor3ub(0,100,0);
    glVertex2f(14,3);
    glVertex2f(15,5);
    glVertex2f(20,5);
    glVertex2f(21,3);
    glEnd();

///polygon2///
    glBegin(GL_POLYGON);
    glColor3ub(0,100,0);
    glVertex2f(15,5);
    glVertex2f(16,6);
    glVertex2f(19,6);
    glVertex2f(20,5);
    glEnd();

///triangle///
    glBegin(GL_TRIANGLES);
    glColor3ub(0,100,0);
    glVertex2f(16,6);
    glVertex2f(19,6);
    glVertex2f(17.5,6.5);
    glEnd();

///hill 2///
///polygon1///
    glBegin(GL_POLYGON);
    glColor3ub(0,100,0);
    glVertex2f(21,3);
    glVertex2f(22,5);
    glVertex2f(24,5);
    glVertex2f(25,3);
    glEnd();

///polygon2///
    glBegin(GL_POLYGON);
    glColor3ub(0,100,0);
    glVertex2f(22,5);
    glVertex2f(22.5,5.5);
    glVertex2f(23.5,5.5);
    glVertex2f(24,5);

    glEnd();

///hill 3///
///polygon1///
    glBegin(GL_POLYGON);
    glColor3ub(0,100,0);
    glVertex2f(25,3);
    glVertex2f(25.5,4.5);
    glVertex2f(28.5,4.5);
    glVertex2f(29,3);
    glEnd();

///polygon2///
    glBegin(GL_POLYGON);
    glColor3ub(0,100,0);
    glVertex2f(25.5,4.5);
    glVertex2f(26,5);
    glVertex2f(28,5);
    glVertex2f(28.5,4.5);
    glEnd();

///hill 4///
///polygon4///
    glBegin(GL_POLYGON);
    glColor3ub(0,100,0);
    glVertex2f(29,3);
    glVertex2f(29.5,4);
    glVertex2f(30.5,4);
    glVertex2f(31,3);
    glEnd();

///triangle///
    glBegin(GL_TRIANGLES);
    glColor3ub(0,100,0);
    glVertex2f(29.5,4);
    glVertex2f(30,4.5);
    glVertex2f(30.5,4);
    glEnd();

///hill 5///
///polygon1///
    glBegin(GL_POLYGON);
    glColor3ub(0,100,0);
    glVertex2f(31,3);
    glVertex2f(31.5,4.5);
    glVertex2f(32.5,4.5);
    glVertex2f(33,3);
    //glVertex2f();
    glEnd();

///triangle///
    glBegin(GL_TRIANGLES);
    glColor3ub(0,100,0);
    glVertex2f(31.5,4.5);
    glVertex2f(32.5,4.5);
    glVertex2f(32,5);
    glEnd();

///hill 6///
///polygon1///
    glBegin(GL_POLYGON);
    glColor3ub(0,100,0);
    glVertex2f(33,3);
    glVertex2f(33.5,4.5);
    glVertex2f(37.5,4.5);
    glVertex2f(38,3);

    glEnd();

///polygon2///
    glBegin(GL_POLYGON);
    glColor3ub(0,100,0);
    glVertex2f(33.5,4.5);
    glVertex2f(34,5);
    glVertex2f(37,5);
    glVertex2f(37.5,4.5);

    glEnd();



    ///////////////
    ///boat motion right to left
    glPushMatrix();
    glTranslatef(movea, 0.0f, 0.0f);
    glBegin(GL_QUADS);   ///middle triangle in boat
    glColor3ub(139,69,19);
        glVertex2f(22.0f, -17.5f);
        glVertex2f(21.0f, -16.5f);
        glVertex2f(17.50f, -16.5f);
        glVertex2f(18.0f, -17.5f);
    glEnd();

    glBegin(GL_QUADS);  ///bottom triangle in boat
    glColor3ub(0,0,0);
        glVertex2f(22.0f, -18.0f);
        glVertex2f(22.0f, -17.5f);
        glVertex2f(17.0f, -17.5f);
        glVertex2f(17.0f, -18.0f);
    glEnd();

    glBegin(GL_QUADS); /// upper triangle( tabo )
    glColor3ub(255,99,71);
        glVertex2f(20.5f, -16.5f);
        glVertex2f(21.0f, -14.5f);
        glVertex2f(18.5f, -14.5f);
        glVertex2f(18.0f, -16.5f);
    glEnd();

    glBegin(GL_QUADS);  /// strick in middle for tabo
    glColor3ub(139,69,19);
        glVertex2f(19.8f, -14.5f);
        glVertex2f(19.8f, -14.0f);
        glVertex2f(19.7f, -14.0f);
        glVertex2f(19.7f, -14.5f);
    glEnd();

    glBegin(GL_TRIANGLES);/// first side triangle in boat
    glColor3ub(0,0,0);
        glVertex2f(17.0f, -18.0f);
        glVertex2f(17.0f, -17.5f);
        glVertex2f(15.5f, -17.2f);

    glEnd();

    glBegin(GL_TRIANGLES);///left triangle in boat
    glColor3ub(0,0,0);
        glVertex2f(22.0f, -17.5f);
        glVertex2f(22.0f, -18.0f);
        glVertex2f(23.5f, -17.2f);

    glEnd();

    glBegin(GL_TRIANGLES);/// front in middle triangle
    glColor3ub(0,0,0);
        glVertex2f(17.0f, -17.5f);
        glVertex2f(18.0f, -17.5f);
        glVertex2f(17.5f, -16.5f);

    glEnd();

    glPopMatrix();


///windmill structure///
    glBegin(GL_POLYGON);/// Draw a Red 1x1 Square centered at origin
    glColor3ub(0,206,209);

    glVertex2f(31.0f,2.0f);
    glVertex2f(30.0f,-6.0f);
    glVertex2f(34.0f,-6.0f);
    glVertex2f(33.0f,2.0f);
    glVertex2f(32.5f,3.0f);
    glVertex2f(31.5f,3.0f);

    glEnd();


     ///circle///
    glPushMatrix();
    glColor3ub(0,0,0);
    glTranslatef(32.0f,3.0f,0.0f);
    glutSolidSphere(0.5,150,150);
	glRotatef(angle1, 0.0f, 0.0f,1.0f);


    glBegin(GL_QUADS);///first stand to hold the blade
    glColor3ub(255,255,0);
    glVertex2f(0.0f,0.0f);
    glVertex2f(5.0f,0.0f);
    glVertex2f(5.0f,0.25f);
    glVertex2f(0.0f,0.25f);
    glEnd();

    glBegin(GL_QUADS);/// second stand to hold the blade
    glColor3ub(255,255,0);
    glVertex2f(0.0f,0.0f);
    glVertex2f(0.0f,5.0f);
    glVertex2f(-0.25f,5.0f);
    glVertex2f(-0.25f,0.0f);
    glEnd();

    glBegin(GL_QUADS);/// third stand to hold the blade
    glColor3ub(255,255,0);
    glVertex2f(0.0f,-0.25f);
    glVertex2f(0.0f,0.0f);
    glVertex2f(-5.0f,0.0f);
    glVertex2f(-5.0f,-0.25f);
    glEnd();

    glBegin(GL_QUADS);/// fourth stand to hold the blade
    glColor3ub(255,255,0);
    glVertex2f(0.25f,0.0f);
    glVertex2f(0.0f,0.0f);
    glVertex2f(0.0f,-5.0f);
    glVertex2f(0.25f,-5.0f);
    glEnd();

    glBegin(GL_TRIANGLES);/// first triangular blade to hold the blade
    glColor3ub(128,0,0);
    glVertex2f(0.25f,0.0f);
    glVertex2f(5.0f,-2.5f);
    glVertex2f(5.0f,0.0f);
    glEnd();

    glBegin(GL_TRIANGLES);/// second triangular blade to hold the blade
    glColor3ub(128,0,0);
    glVertex2f(0.0f,0.025f);
    glVertex2f(2.5f,5.0f);
    glVertex2f(0.0f,5.0f);
    glEnd();

    glBegin(GL_TRIANGLES);/// third triangular blade to hold the blade
    glColor3ub(128,0,0);
    glVertex2f(-0.25f,0.0f);
    glVertex2f(-5.0f,2.5f);
    glVertex2f(-5.0f,0.0f);
    glEnd();

    glBegin(GL_TRIANGLES);/// fourth triangular blade to hold the blade
    glColor3ub(128,0,0);
    glVertex2f(0.0f,-0.025f);
    glVertex2f(-2.5f,-5.0f);
    glVertex2f(0.0f,-5.0f);
    glEnd();

    glPopMatrix();

    glutSwapBuffers();/// the back buffer of the layer in use of the current window to become the contents of the front buffer.
}

/// update for boat
void update1(int value) {

    if(movea < -10)
    {
        movea = +38;
    }

 movea -= 0.15;

    glutTimerFunc(20, update1, 0); ///Notify GLUT to call update again in 25 milliseconds
    glutPostRedisplay(); ///Notify GLUT that the display has changed

}

///update for windlmill
void update2(int value) {

    angle1-=2.0f;
    if(angle1 > 360.0)
    {
        angle1-=360;
    }
	glutPostRedisplay(); ///Notify GLUT that the display has changed

	glutTimerFunc(10, update2, 0); ///Notify GLUT to call update again in 25 milliseconds
}
///cloud moution update
void update3(int value) {


    if(moveb > +36)
    {
        moveb= -10;
    }
     ///Notify GLUT that the display has changed

 moveb += 0.13;

    glutTimerFunc(20, update3, 0); ///Notify GLUT to call update again in 25 milliseconds
    glutPostRedisplay();

}

int main() {

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);/// set the display mode

    glutInitWindowSize(1500, 1000); ///Set the window's initial width & height
    glutCreateWindow("CSE420_2D PROJECT"); /// Create window with the given title

    glutDisplayFunc(drawScene);  /// Register callback handler for window re-paint event
    glutTimerFunc(20, update1, 0); /// a timer callback to be triggered in a specified number of milliseconds.

    glutTimerFunc(10, update2, 0);
    glutTimerFunc(20, update3, 0);

    glutMainLoop(); /// Enter the event-processing loop
    return 0;
}
